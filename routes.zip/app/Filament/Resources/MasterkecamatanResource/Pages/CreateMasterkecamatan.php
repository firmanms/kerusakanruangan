<?php

namespace App\Filament\Resources\MasterkecamatanResource\Pages;

use App\Filament\Resources\MasterkecamatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMasterkecamatan extends CreateRecord
{
    protected static string $resource = MasterkecamatanResource::class;
}
