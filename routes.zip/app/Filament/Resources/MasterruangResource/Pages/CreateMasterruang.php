<?php

namespace App\Filament\Resources\MasterruangResource\Pages;

use App\Filament\Resources\MasterruangResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMasterruang extends CreateRecord
{
    protected static string $resource = MasterruangResource::class;
}
