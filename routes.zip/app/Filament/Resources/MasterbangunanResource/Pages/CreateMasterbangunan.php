<?php

namespace App\Filament\Resources\MasterbangunanResource\Pages;

use App\Filament\Resources\MasterbangunanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMasterbangunan extends CreateRecord
{
    protected static string $resource = MasterbangunanResource::class;
}
