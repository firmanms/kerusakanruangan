<?php

namespace App\Filament\Resources\TanahResource\Pages;

use App\Filament\Resources\TanahResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTanah extends CreateRecord
{
    protected static string $resource = TanahResource::class;
}
