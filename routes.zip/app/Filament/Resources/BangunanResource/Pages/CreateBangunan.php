<?php

namespace App\Filament\Resources\BangunanResource\Pages;

use App\Filament\Resources\BangunanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBangunan extends CreateRecord
{
    protected static string $resource = BangunanResource::class;
}
