<?php

namespace App\Filament\Resources\MasterdesaResource\Pages;

use App\Filament\Resources\MasterdesaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMasterdesa extends CreateRecord
{
    protected static string $resource = MasterdesaResource::class;
}
