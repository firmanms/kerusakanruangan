<?php

namespace App\Filament\Resources\RuangResource\Pages;

use App\Filament\Resources\RuangResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRuang extends CreateRecord
{
    protected static string $resource = RuangResource::class;
}
