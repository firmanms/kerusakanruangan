<?php

namespace App\Filament\Resources\MasterjenisprasaranaResource\Pages;

use App\Filament\Resources\MasterjenisprasaranaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMasterjenisprasarana extends CreateRecord
{
    protected static string $resource = MasterjenisprasaranaResource::class;
}
